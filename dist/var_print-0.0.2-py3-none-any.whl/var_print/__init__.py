from .varPrint import varp, varpFore

__version__ = "0.0.2"
